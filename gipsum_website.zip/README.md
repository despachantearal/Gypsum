# Gipsum Pro Website

Website sederhana bertema gipsum untuk kebutuhan portofolio atau bisnis.

## Fitur
- Landing page sederhana
- Desain minimalis
- Mudah dikembangkan

## Cara Menjalankan
Cukup buka file `index.html` di browser.

## Author
Dibuat untuk project GitHub 🚀
